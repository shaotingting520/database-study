def main():
    print("Hello from djwork!")


if __name__ == "__main__":
    main()
