from django.contrib import admin

# Register your models here.
from .models import Language, Film, Category, FilmCategory

class FilmAdmin(admin.ModelAdmin):
    list_display = ['title', 'language_id']

admin.site.register(Film, FilmAdmin)

class LanguageAdmin(admin.ModelAdmin):
    list_display = ['name', 'last_update']

admin.site.register(Language, LanguageAdmin)

admin.site.register(Category)

admin.site.register(FilmCategory)