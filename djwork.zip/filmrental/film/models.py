from django.db import models

# Create your models here.
class Language(models.Model):
    name = models.CharField(max_length=100)
    last_update = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name
    
class Film(models.Model):
    title = models.CharField(max_length=300)
    language_id = models.ForeignKey(Language, on_delete=models.RESTRICT)

    def __str__(self):
        return self.title
    
class Category(models.Model):
    name = models.CharField(max_length=100)
    last_update = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name
    
class FilmCategory(models.Model):
    film_id = models.ForeignKey(Film, on_delete=models.RESTRICT)
    category_id = models.ForeignKey(Category, on_delete=models.RESTRICT)
    last_update = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('film_id', 'category_id')