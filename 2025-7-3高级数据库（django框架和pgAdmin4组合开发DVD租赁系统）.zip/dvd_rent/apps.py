from django.apps import AppConfig


class DvdRentConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dvd_rent'
