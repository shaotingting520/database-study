from django.db import models

# Create your models here.
class Category(models.Model):
      category_id = models.AutoField(primary_key=True)
      category_name = models.CharField(max_length=100)
      category_last_update = models.DateTimeField(auto_now=True)

      def __str__(self):
        return self.category_name


class Language(models.Model):
    language_id = models.AutoField(primary_key=True)
    language_name = models.CharField(max_length=100)
    language_last_update = models.DateTimeField(auto_now=True)
        
    def __str__(self):
        return self.language_name
    
#class Meta

class Dvd_rent(models.Model):
    dvd_id = models.AutoField(primary_key=True)
    language_id = models.ForeignKey(Language,on_delete=models.CASCADE) 
    dvd_rent_title = models.CharField(max_length=300)
    content = models.TextField()


    def __str__(self):
            return self.dvd_rent_title
    
class Film_category(models.Model):
      dvd_id = models.ForeignKey(Dvd_rent,on_delete=models.CASCADE)
      category_id = models.ForeignKey(Category,on_delete=models.CASCADE)
      film_category_name = models.CharField(max_length=100)
      category_last_update = models.DateTimeField(auto_now=True)

      def __str__(self):
        return self.film_category_name
      
class Film_category(models.Model):
      dvd_id = models.ForeignKey(Dvd_rent,on_delete=models.CASCADE)
      category_id = models.ForeignKey(Category,on_delete=models.CASCADE)
      film_category_name = models.CharField(max_length=100)
      category_last_update = models.DateTimeField(auto_now=True)

      def __str__(self):
        return self.film_category_name