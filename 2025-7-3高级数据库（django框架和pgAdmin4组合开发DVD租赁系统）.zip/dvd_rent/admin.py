from django.contrib import admin
from .models import Category,Dvd_rent,Film_category,Language

# Register your models here.



admin.site.register(Category)
admin.site.register(Dvd_rent)
admin.site.register(Film_category)
admin.site.register(Language)


